# 📊 Trading Assistant

**Version**: 2.0.0 | **License**: MIT

专业的投资分析工具，提供技术指标、交易信号和持仓管理功能。

---

## ✨ 主要功能

- **技术指标**: RSI, MACD, 布林带，KDJ, CCI 等 10 种指标
- **交易信号**: 自动生成买入/卖出/持有信号
- **仓位管理**: 智能计算仓位大小
- **支撑阻力**: 自动计算关键价格位
- **多市场支持**: A 股、美股、加密货币
- **日报系统**: 早盘预期 + 盘后总结
- **新闻情绪**: 市场新闻分析

---

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置 API 密钥

创建 `.env` 文件：

```bash
TWELVE_DATA_API_KEY=你的密钥
ALPHA_VANTAGE_API_KEY=你的密钥
```

免费获取 API 密钥：
- Twelve Data: https://twelvedata.com
- Alpha Vantage: https://www.alphavantage.co

### 3. 测试

```bash
python3 support_resistance.py
python3 trading_signals.py
```

---

## 📖 基本使用

### 生成交易信号

```python
from trading_signals import generate_trading_signal
result = generate_trading_signal("AAPL")
print(result)
```

### 计算仓位

```python
from position_calculator import calculate_position_size
result = calculate_position_size(
    total_capital=100000,
    entry_price=175.64,
    stop_loss_price=165.00,
    risk_profile="moderate"
)
```

### 计算支撑阻力

```python
from support_resistance import calculate_support_resistance
result = calculate_support_resistance("NVDA")
```

---

## 📁 目录结构

```
trading-assistant/
├── SKILL.md                 # 技能描述
├── README.md                # 使用文档
├── README_en.md             # English docs
├── requirements.txt         # 依赖
├── .env.example             # 配置模板
├── config.py                # 配置
├── support_resistance.py    # 支撑阻力
├── trading_signals.py       # 交易信号
├── position_calculator.py   # 仓位计算
├── daily_report.py          # 日报生成
├── portfolio_manager.py     # 持仓管理
└── news_sentiment_monitor.py # 新闻情绪
```

---

## 🔒 安全说明

### 本工具会：
- ✅ 从环境变量读取 API 密钥
- ✅ 调用 Twelve Data 和 Alpha Vantage API
- ✅ 在本地生成报告和日志

### 本工具不会：
- ❌ 访问项目目录外的文件
- ❌ 执行外部代码
- ❌ 需要券商或交易所凭证
- ❌ 执行实际交易

**注意**: 仅提供 Twelve Data 和 Alpha Vantage 的 API 密钥，不要提供券商凭证。

---

## 📚 详细文档

查看 `docs/` 目录获取完整使用指南：

- 安装指南
- 技术指标说明
- 交易信号使用
- 仓位管理
- 日报系统
- API 密钥配置

---

## ⚠️ 免责声明

**仅供教育和研究使用，不构成投资建议。**

- 市场投资有风险
- 历史表现不代表未来
- 用户需自行承担投资决策
- 本工具不执行交易

---

## 🔗 链接

- **GitHub**: https://github.com/XuXuClassMate/trading-assistant
- **问题反馈**: https://github.com/XuXuClassMate/trading-assistant/issues

---

**版本**: 2.0.0  
**更新日期**: 2026-03-28
