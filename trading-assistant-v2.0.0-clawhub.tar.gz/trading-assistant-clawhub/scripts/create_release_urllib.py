#!/usr/bin/env python3
"""Create GitHub Release using urllib"""

import urllib.request
import json

TOKEN = "${GITHUB_TOKEN}"
REPO = "XuXuClassMate/trading-assistant"

url = f"https://api.github.com/repos/{REPO}/releases"

data = {
    "tag_name": "v1.0.0",
    "target_commitish": "main",
    "name": "v1.0.0 - Initial Release",
    "body": """## OpenClaw Trading Assistant v1.0.0

### Features

- Support & Resistance calculation
- Trading signals (RSI, MACD, MA)
- Position calculator
- Multi-language (English/Chinese)
- Configurable notifications
- Portfolio allocation

### Documentation

- English: README_en.md
- Chinese: README_zh.md
- Configuration: docs/CONFIGURATION.md
- Changelog: CHANGELOG.md

### Installation

```bash
git clone https://github.com/XuXuClassMate/trading-assistant.git
cd trading-assistant
pip install -r requirements.txt
```

https://github.com/XuXuClassMate/trading-assistant
""",
    "draft": False,
    "prerelease": False
}

req = urllib.request.Request(
    url,
    data=json.dumps(data).encode('utf-8'),
    headers={
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github.v3+json",
        "Content-Type": "application/json"
    },
    method='POST'
)

try:
    print("Creating GitHub Release v1.0.0...")
    with urllib.request.urlopen(req, timeout=30) as response:
        result = json.loads(response.read().decode())
        print("✅ Release created successfully!")
        print(f"Name: {result['name']}")
        print(f"Tag: {result['tag_name']}")
        print(f"URL: {result['html_url']}")
except urllib.error.HTTPError as e:
    print(f"HTTP Error: {e.code}")
    print(f"Response: {e.read().decode()}")
except Exception as e:
    print(f"Error: {e}")
