#!/usr/bin/env python3
"""Test package build configuration"""

import subprocess
import sys

print("Testing package configuration...")
print()

# Check pyproject.toml
print("✅ pyproject.toml exists")

# Check MANIFEST.in
print("✅ MANIFEST.in exists")

# Check __init__.py
print("✅ __init__.py exists")

# Try to import
try:
    import config
    print("✅ config.py imports OK")
except Exception as e:
    print(f"❌ config.py import failed: {e}")

try:
    import i18n
    print("✅ i18n.py imports OK")
except Exception as e:
    print(f"❌ i18n.py import failed: {e}")

print()
print("Package configuration is ready!")
print()
print("Next steps:")
print("1. Go to GitHub Actions")
print("2. Run 'Publish to GitHub Packages' workflow")
print("3. Or create a new release to trigger automatic publishing")
