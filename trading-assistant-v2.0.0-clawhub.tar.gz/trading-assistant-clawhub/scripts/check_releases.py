#!/usr/bin/env python3
"""Check GitHub Releases"""

import urllib.request
import json

TOKEN = "${GITHUB_TOKEN}"
REPO = "XuXuClassMate/trading-assistant"

url = f"https://api.github.com/repos/{REPO}/releases"

req = urllib.request.Request(url)
req.add_header("Authorization", f"token {TOKEN}")
req.add_header("Accept", "application/vnd.github.v3+json")

try:
    with urllib.request.urlopen(req, timeout=10) as response:
        data = json.loads(response.read().decode())
        print(f"Total Releases: {len(data)}")
        print()
        if data:
            for release in data:
                print(f"Tag: {release['tag_name']}")
                print(f"Name: {release['name']}")
                print(f"URL: {release['html_url']}")
                print(f"Published: {release['published_at']}")
                print()
        else:
            print("No releases found.")
except Exception as e:
    print(f"Error: {e}")
