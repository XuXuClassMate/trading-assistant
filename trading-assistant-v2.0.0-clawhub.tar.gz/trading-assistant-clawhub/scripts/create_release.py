#!/usr/bin/env python3
"""Create GitHub Release"""

import requests
import json

TOKEN = "${GITHUB_TOKEN}"
REPO = "XuXuClassMate/trading-assistant"

headers = {
    "Authorization": f"token {TOKEN}",
    "Accept": "application/vnd.github.v3+json"
}

data = {
    "tag_name": "v1.0.0",
    "target_commitish": "main",
    "name": "v1.0.0 - Initial Release",
    "body": """## 🚀 OpenClaw Trading Assistant v1.0.0

### ✨ Features

- 📊 Support & Resistance level calculation
- 📈 Trading signal generation (RSI, MACD, MA)
- 💰 Position size calculator
- 🌍 Multi-language support (English/Chinese)
- 🔔 Configurable notifications
- 📊 Portfolio allocation

### 📖 Documentation

- **English**: [README_en.md](https://github.com/XuXuClassMate/trading-assistant/blob/main/README_en.md)
- **中文**: [README_zh.md](https://github.com/XuXuClassMate/trading-assistant/blob/main/README_zh.md)
- **Configuration**: [docs/CONFIGURATION.md](https://github.com/XuXuClassMate/trading-assistant/blob/main/docs/CONFIGURATION.md)
- **Changelog**: [CHANGELOG.md](https://github.com/XuXuClassMate/trading-assistant/blob/main/CHANGELOG.md)

### 🛠️ Installation

```bash
git clone https://github.com/XuXuClassMate/trading-assistant.git
cd trading-assistant
pip install -r requirements.txt
```

### ⚙️ Quick Start

1. Copy `.env.example` to `.env` and add your API Keys
2. Copy `watchlist.txt.example` to `watchlist.txt` and add your stocks
3. Run `python3 support_resistance.py` to test

### 📚 Full Documentation

https://github.com/XuXuClassMate/trading-assistant#readme

---

**Made with ❤️ by OpenClaw Community**
""",
    "draft": False,
    "prerelease": False
}

url = f"https://api.github.com/repos/{REPO}/releases"

print("Creating GitHub Release v1.0.0...")
response = requests.post(url, headers=headers, json=data)

print(f"Status Code: {response.status_code}")
print(f"Response: {json.dumps(response.json(), indent=2)}")

if response.status_code == 201:
    print("\n✅ Release created successfully!")
    print(f"URL: {response.json()['html_url']}")
else:
    print("\n❌ Failed to create release")
